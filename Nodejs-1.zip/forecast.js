const request = require('request')

function cbk(err,data){
  if(data){
    console.log("this is lat lon data",data);
  }
  else{
    console.log("error occured in fetching lat lon")
  }
}

const forecast = (latitude,longitude,callback)=>{
  let url = `https://api.weatherstack.com/current?access_key=72b83cbea4cee2b27e9a6721b352a7e6&query=${latitude},${longitude}`;
  request({url:url,json:true},(err,res)=>{
    const data = res.body.current;
    callback(err,data)
  })
}
module.exports = {forecast,cbk}