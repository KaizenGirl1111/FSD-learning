const request = require("request");
/*
function cbk(err, res) {
    if (err) {
        console.log(err);
    } else {
        console.log(res);
    }
}
*/
function geocode(location, callback) {
    let url = `https://api.weatherstack.com/current?access_key=72b83cbea4cee2b27e9a6721b352a7e6&query=${location}`;
    // request
    console.log(location)
    request({ url, json: true }, (err, res) => {
        const data = res.body;
        callback(err, data);
    });
}

//geocode("New York", cbk);

module.exports = geocode;
