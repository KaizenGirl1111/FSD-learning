console.log("Avni");
const express = require("express");
const app = express();
const PORT = 8000;
app.listen(PORT, () => {
  console.log("Listening at: ", PORT);
});

app.get("/", (req, res) => {
  res.send("Home page activated");
});

app.get("/home", (req, res) => {
  res.send("<h1>Over the home page</h1>");
});

app.get("/help", (req, res) => {
  res.send({
    name: "Avni",
    age: 20,
    phone: 2423034334,
  });
});

//res.send server responding
app.get("/weather", (req, res) => {
  console.log(req.query);
  //res.send("Weather page")
  // res.send(`${res.query.name}`)
  res.send({
    city: req.query.city,
    state: req.query.state,
    temp: req.query.temp,
    humidity: req.query.humidity,
    country: "India",
  });
});

app.get("/forecast/:id", (req, res) => {
  console.log(req.params);
  res.send({
    id: req.params.id,
    message: "Id fetched",
  });
});
const movies = [
  {
    name: "Black Swan",
    poster:
      "https://upload.wikimedia.org/wikipedia/en/6/68/Black_Swan_poster.jpg",
    rating: 8,
    summary:
      "A psychological thriller that follows the intense rivalry between two ballet dancers competing for the lead role in a production of 'Swan Lake', blurring the lines between reality and hallucination.",
    glimpse: "https://www.youtube.com/watch?v=5jaI1XOB-bs",
    director: "Darren Aronofsky",
    year: 2010,
    cast: ["Natalie Portman", "Mila Kunis"],
    genre: "Thriller",
    id: "1",
  },
  {
    name: "Before Sunrise",
    poster:
      "https://upload.wikimedia.org/wikipedia/en/d/da/Before_Sunrise_poster.jpg",
    rating: 8.1,
    summary:
      "A romantic drama that unfolds over the course of a single night in Vienna, as two strangers, an American man and a French woman, explore the city and share intimate conversations.",
    glimpse: "https://youtu.be/6MUcuqbGTxc?si=ws6reRq5We17Smdi",
    trailer: "https://www.youtube.com/embed/6MUcuqbGTxc?si=ShGVvw3vMVBojbmz",
    director: "Richard Linklater",
    year: 1995,
    cast: ["Ethan Hawke", "Julie Delpy"],
    genre: "Romance",
    id: "2",
  },
  {
    name: "Whiplash",
    poster:
      "https://upload.wikimedia.org/wikipedia/en/0/01/Whiplash_poster.jpg",
    rating: 8.5,
    summary:
      "A gripping drama about the intense relationship between a young jazz drummer and his abusive instructor at a prestigious music academy.",
    glimpse: "https://youtu.be/7d_jQycdQGo?si=wrSDLPDbwzkmo1QV",
    director: "Damien Chazelle",
    year: 2014,
    cast: ["Miles Teller", "J.K. Simmons"],
    genre: "Drama",
    id: "3",
  },
  {
    name: "Babylon",
    poster:
      "https://upload.wikimedia.org/wikipedia/en/d/db/Babylon_2022_poster.jpg",
    rating: 6.5,
    summary:
      "Set in 1980s London, 'Babylon' follows a young South London DJ as he navigates the music industry and racial tensions while pursuing his dreams of success.",
    glimpse: "https://youtu.be/t7HT83wkVss?si=_aFL7uKCAtXZedDY",
    director: "Damien Chazelle",
    year: 1980,
    cast: ["Brinsley Forde", "Karl Howman"],
    genre: "Thriller",
    id: "4",
  },
  {
    name: "In Mood for Love",
    poster:
      "https://upload.wikimedia.org/wikipedia/en/4/45/In_the_Mood_for_Love_movie.jpg",
    rating: 8.1,
    summary:
      "A visually stunning exploration of love, longing, and missed connections in 1960s Hong Kong, 'In the Mood for Love' is a masterpiece of Wong Kar Wai.",
    glimpse: "https://youtu.be/m8GuedsQnWQ?si=kVtdzZsW5FFv74-x",
    director: "Wong Kar Wai",
    year: 2000,
    cast: ["Tony Leung", "Maggie Cheung"],
    genre: "Romance",
    id: "5",
  },
  {
    name: "La La Land",
    poster:
      "https://upload.wikimedia.org/wikipedia/en/a/ab/La_La_Land_%28film%29.png",
    rating: 8,
    summary:
      "A modern musical that captures the bittersweet essence of chasing dreams in Los Angeles, 'La La Land' is a visually stunning and emotionally resonant film by Damien Chazelle.",
    glimpse: "https://youtu.be/0pdqf4P9MB8?si=JyQfS6lorY-R4cyG",
    director: "Damien Chazelle",
    year: 2016,
    cast: ["Ryan Gosling", "Emma Stone"],
    genre: "Romance",
    id: "6",
  },
  {
    name: "Once Upon a Time in Hollywood",
    poster:
      "https://upload.wikimedia.org/wikipedia/en/a/a6/Once_Upon_a_Time_in_Hollywood_poster.png",
    rating: 7.6,
    summary:
      "Quentin Tarantino's ode to Hollywood's golden age, 'Once Upon a Time in Hollywood' intertwines the lives of a fading TV star and his stunt double with the Manson Family murders.",
    glimpse: "https://youtu.be/ELeMaP8EPAA?si=jzqdJiYJgK8Q-OWJ",
    director: "Quentin Tarantino",
    year: 2019,
    cast: ["Leonardo DiCaprio", "Brad Pitt"],
    genre: "Thriller",
    id: "7",
  },
  {
    name: "Udaan",
    poster:
      "https://upload.wikimedia.org/wikipedia/en/7/71/Udaan_Movie_Poster.jpg",
    rating: 8.1,
    summary:
      "A coming-of-age drama about a teenager's journey of self-discovery and rebellion against his authoritarian father, 'Udaan' is a powerful film by Vikramaditya Motwane.",
    glimpse: "https://youtu.be/wEJxe2bE-cE?si=9PfMsFlX6XK34dT0",
    director: "Vikramaditya Motwane",
    year: 2010,
    cast: ["Rajat Barmecha", "Ronit Roy"],
    genre: "Drama",
    id: "8",
  },
  {
    name: "Masaan",
    poster: "https://upload.wikimedia.org/wikipedia/en/1/1c/Masaan_poster.jpg",
    rating: 8.1,
    summary:
      "A powerful drama set in the holy city of Varanasi, 'Masaan' explores themes of love, loss, and redemption through the lives of its characters.",
    glimpse: "https://youtu.be/SKJfBo3xMW0?si=zkgoK5nijp_Ws3Li",
    director: "Neeraj Ghaywan",
    year: 2015,
    cast: ["Richa Chadha", "Vicky Kaushal"],
    genre: "Thriller",
    id: "9",
  },
  {
    name: "Jab We Met Returns",
    poster:
      "https://upload.wikimedia.org/wikipedia/en/9/9f/Jab_We_Met_Poster.jpg",
    rating: 7.9,
    summary:
      "A romantic comedy about two strangers who meet on a train journey and embark on an adventurous and transformative road trip together.",
    glimpse: "https://youtu.be/Z6cE7g9feSs?si=91uMA8mRUxdS964f",
    director: "Imtiaz Ali",
    year: 2007,
    cast: ["Shahid Kapoor", "Kareena Kapoor Khan"],
    genre: "Romance",
    id: "10",
  },
  {
    name: "Sir",
    poster: "https://upload.wikimedia.org/wikipedia/en/f/fc/Sir_film.jpg",
    rating: 7.2,
    summary:
      "A tender romance between a wealthy young man and his live-in maid, 'Sir' explores the complexities of class divide and societal norms.",
    glimpse: "https://youtu.be/h36-Hkno6QQ?si=kBgxbsVypRDYn-ut",
    director: "Rohena Gera",
    year: 2020,
    cast: ["Tillotama Shome", "Vivek Gomber"],
    genre: "Romance",
    id: "11",
  },
  {
    name: "Chhichhore",
    poster:
      "https://upload.wikimedia.org/wikipedia/en/3/3d/Chhichhore_Poster.jpg",
    rating: 7.6,
    summary:
      "A heartwarming tale about a group of college friends who reunite years later to support one of their own and reminisce about their unforgettable days together.",
    glimpse: "https://youtu.be/tsxemFX0a7k?si=zZzHqr4h-QTbArX1",
    director: "Nitesh Tiwari",
    year: 2019,
    cast: ["Sushant Singh Rajput", "Shraddha Kapoor"],
    genre: "Drama",
    id: "12",
  },
  {
    name: "Tanu Weds Manu 2",
    poster:
      "https://upload.wikimedia.org/wikipedia/en/3/3f/Tanu_weds_Manu_poster.jpg",
    rating: 7.5,
    summary:
      "A quirky romantic comedy sequel that follows the tumultuous lives of Tanu and Manu, exploring love, marriage, and second chances.",
    glimpse: "https://youtu.be/wGGmyaurjAI?si=GWwDBvkWeOHrPO-I",
    director: "Aanand L. Rai",
    year: 2015,
    cast: ["Kangana Ranaut", "R. Madhavan"],
    genre: "Drama",
    id: "13",
  },
  {
    name: "Peepli Live",
    poster: "https://upload.wikimedia.org/wikipedia/en/5/55/Peeplilive.jpg",
    rating: 7.5,
    summary:
      "A satirical comedy-drama that sheds light on the media circus surrounding farmer suicides in rural India and the political exploitation of their plight.",
    glimpse: "https://youtu.be/ht0-gqvFor0?si=AQic8ACFsZBlXEVs",
    director: "Anusha Rizvi",
    year: 2010,
    cast: ["Omkar Das Manikpuri", "Raghubir Yadav"],
    genre: "Drama",
    id: "14",
  },
  {
    name: "Casablanca",
    poster:
      "https://m.media-amazon.com/images/I/81vQ31ZbomL._AC_UF1000,1000_QL80_.jpg",
    rating: 8.5,
    summary:
      "A timeless romantic drama set during World War II, showcasing love, sacrifice, and political intrigue in the Moroccan city of Casablanca.",
    glimpse: "https://youtu.be/MF7JH_54d8c?si=S_utzuo1aKb4qRDL",
    director: "Michael Curtiz",
    year: 1942,
    cast: ["Humphrey Bogart", "Ingrid Bergman"],
    genre: "Thriller",
    id: "15",
  },
  {
    name: "Pyaasa",
    poster: "https://upload.wikimedia.org/wikipedia/en/9/93/Pyaasa_poster.jpg",
    rating: 7,
    summary:
      "Considered a masterpiece of Indian cinema, 'Pyaasa' tells the story of a struggling poet who finds solace and purpose amidst societal indifference and personal turmoil.",
    glimpse: "https://youtu.be/pBZYJAzz5ys?si=sn_IgsHHw6-h-F3R",
    director: "Guru Dutt",
    year: 1957,
    cast: ["Guru Dutt", "Waheeda Rehman"],
    genre: "Classic",
    id: "16",
  },
  {
    name: "Pather Panchali",
    poster:
      "https://images.squarespace-cdn.com/content/v1/5befb3b84611a081dd003798/1618119957942-CX3XM1T6CCU4KPW0FNRK/Pather+Panchali+%5BA+Song+of+the+Little+Road+1955.jpg",
    rating: 8.6,
    summary:
      "Regarded as one of the greatest films in world cinema, 'Pather Panchali' is a lyrical portrayal of childhood, poverty, and dreams in rural Bengal, directed by Satyajit Ray.",
    glimpse:
      "https://imdb-video.media-imdb.com/vi3114774553/1401497881123-xszl4z-1430514845919.mp4?Expires=1711952609&Signature=lk5dKZIEn2BMShbg5kb9V3uBa6snqpOKdIbyN~JwVrQvXNzXxYs87yMPQkaKhEcbYZEWoA6OuRHrGZkXrnNbHw-~lHmjKXkfhkBFcur68rEmDzs2r03CnSFL-kliwe3jymq8wAmsV51Di~~WUDxO01xdCGi2KJCvKEVQtoKv4K2b1e4AdalI5DLUmzZ1MmKlvE3tYCW-MUmLns6I1DN3yr34dHvmvlsDEXucPMv-juSYIytBMEGdmIWiAiIRiqMG3UiRkHAo60~Y9SprWuiO3YJc4IAgkVdk-7kfvo7f~6cWkEc-HUjx4MqJjhnKvhYjaGDluuPKwNGe3pxT3BPajA__&Key-Pair-Id=APKAIFLZBVQZ24NQH3KA",
    director: "Satyajit Ray",
    year: 1955,
    cast: ["Kanu Banerjee", "Karuna Banerjee"],
    genre: "Classic",
    id: "17",
  },
  {
    name: "The Seventh Seal",
    poster:
      "https://upload.wikimedia.org/wikipedia/en/6/69/Seventhsealposter.jpg",
    rating: 6.8,
    summary:
      "A landmark of Swedish cinema, 'The Seventh Seal' follows a medieval knight's existential crisis as he plays a game of chess with Death, exploring themes of faith",
    glimpse: "https://www.youtube.com/watch?v=NtkFei4wRjE",
    director: "Ingmar Bergman",
    year: 1957,
    cast: ["Max von Sydow", "Bengt Ekerot"],
    genre: "Classic",
    id: "18",
  },
  {
    name: "Persona",
    poster:
      "https://m.media-amazon.com/images/M/MV5BYmFlOTcxMWUtZTMzMi00NWIyLTkwOTEtNjIxNmViNzc2Yzc1XkEyXkFqcGdeQXVyMjUzOTY1NTc@._V1_FMjpg_UX1000_.jpg",
    rating: 6.6,
    summary:
      "Directed by Ingmar Bergman, 'Persona' is an enigmatic psychological drama exploring the blurred boundaries between identity,reality and illusions",
    glimpse: "https://youtu.be/amxvetvKfho?si=p5f2KcIMJQ3XAGX4",
    director: "Ingmar Bergman",
    year: 1966,
    cast: ["Bibi Andersson", "Liv Ullmann"],
    genre: "Thriller",
    id: "19",
  },
  {
    name: "Citizen Kane",
    poster:
      "https://resizing.flixster.com/-XZAfHZM39UwaGJIFWKAE8fS0ak=/v3/t/assets/p1485_p_v8_aa.jpg",
    rating: "7",
    summary:
      "Regarded as one of the greatest films ever made, 'Citizen Kane' follows the life and legacy of a wealthy newspaper tycoon, exploring themes of power & corruption. All time classic.",
    glimpse: "https://youtu.be/8dxh3lwdOFw?si=Yt6AFys8_0Qhe1r-",
    director: "Orson .W.",
    year: "1946",
    cast: ["Orson Welles", "Joseph Cotten"],
    genre: "Classic",
    id: "20",
  },
  {
    name: "Gone with Wind",
    poster:
      "https://upload.wikimedia.org/wikipedia/commons/thumb/2/27/Poster_-_Gone_With_the_Wind_01.jpg/330px-Poster_-_Gone_With_the_Wind_01.jpg",
    rating: 8.1,
    summary:
      "A sweeping epic set against the backdrop of the American Civil War and Reconstruction era, 'Gone with the Wind' portrays the tumultuous romance.",
    glimpse: "https://youtu.be/0X94oZgJis4?si=yi4iNYhx_ySQ0P5e",
    director: "Victor Fleming",
    year: 1939,
    cast: ["Clark Gable", "Vivien Leigh"],
    genre: "Romance",
    id: "21",
  },
  {
    name: "Sholay",
    poster: "https://upload.wikimedia.org/wikipedia/en/5/52/Sholay-poster.jpg",
    rating: 8.2,
    summary:
      "An iconic Bollywood classic, 'Sholay' is a tale of friendship, revenge, and redemption set in the lawless village of Ramgarh, featuring memorable characters.",
    glimpse: "https://youtu.be/zzTUvWfvlBg?si=ru_MH9bZSCi6Rmmg",
    director: "Ramesh Sippy",
    year: 1975,
    cast: ["Dharmendra", "Amitabh Bachchan"],
    genre: "Classic",
    id: "22",
  },
  {
    name: "La Dolce Vita",
    poster:
      "https://upload.wikimedia.org/wikipedia/en/c/c1/La_Dolce_Vita_%281960_film%29_coverart.jpg",
    rating: 8,
    summary:
      "Federico Fellini's masterpiece, 'La Dolce Vita', is a satirical take on the hedonistic lifestyles of the Roman elite, capturing the emptiness beneath the glamour of society.",
    glimpse: "https://youtu.be/1BeWEPXWDX4?si=hOryPsFHIlwyvwR5",
    director: "Federico Fellini",
    year: 1960,
    cast: ["Marcello Mastroianni", "Anita Ekberg"],
    genre: "Classic",
    id: "23",
  },
  {
    name: "Mahanagar",
    poster: "https://upload.wikimedia.org/wikipedia/en/1/18/Mahanagar2.jpg",
    rating: 8.2,
    summary:
      "Directed by Satyajit Ray, 'Mahanagar' (The Big City) explores the evolving role of women in Indian society through the journey of a housewife who takes up a job.",
    glimpse: "https://youtu.be/HGA8WBTvQco?si=6LLaajAjbCB7SUi8",
    year: 1963,
    cast: ["Madhabi Mukherjee", "Anil Chatterjee"],
    genre: "Drama",
    id: "24",
  },
  {
    name: "Willms, Keebler and Koepp",
    poster: "https://loremflickr.com/640/480/cats",
    rating: 29345,
    summary:
      "Veniam tenetur dolores.\nQuia perferendis vero rerum.\nConsequuntur impedit expedita blanditiis ab culpa odio.\nNeque veritatis incidunt quasi adipisci voluptate.\nLaudantium cupiditate maxime doloremque.",
    glimpse:
      "https://cloudflare-ipfs.com/ipfs/Qmd3W5DuhgHirLHGVixi6V76LhCkZUz6pnFt5AJBiyvHye/avatar/345.jpg",
    director: "Tonya Lang III",
    year: 42632,
    cast: [],
    genre: "Stage And Screen",
    id: "25",
  },
  {
    name: "Boyle, Wunsch and Macejkovic",
    poster: "https://loremflickr.com/640/480/cats",
    rating: 80010,
    summary:
      "Praesentium et consequatur voluptatum dicta molestias rerum.\nSed doloribus sit alias deserunt.\nAliquid maiores incidunt fugit accusamus asperiores praesentium quaerat dignissimos id.",
    glimpse:
      "https://cloudflare-ipfs.com/ipfs/Qmd3W5DuhgHirLHGVixi6V76LhCkZUz6pnFt5AJBiyvHye/avatar/661.jpg",
    director: "Clint Emmerich",
    year: 32780,
    cast: [],
    genre: "Funk",
    id: "26",
  },
  {
    name: "Fisher - Lind",
    poster: "https://loremflickr.com/640/480/cats",
    rating: 34232,
    summary:
      "Voluptatem explicabo maiores in autem sint.\nExplicabo aut vitae veniam velit quisquam ipsa quam nesciunt sit.\nVoluptatibus debitis adipisci esse quo debitis consectetur corrupti voluptate.\nFacere quia tempore exercitationem minima.\nLaudantium deleniti ullam delectus amet tempore ratione cupiditate quisquam.",
    glimpse:
      "https://cloudflare-ipfs.com/ipfs/Qmd3W5DuhgHirLHGVixi6V76LhCkZUz6pnFt5AJBiyvHye/avatar/305.jpg",
    director: "Pedro Stracke",
    year: 21282,
    cast: [],
    genre: "Latin",
    id: "27",
  },
  {
    name: "Fisher Inc",
    poster: "https://loremflickr.com/640/480/cats",
    rating: 54681,
    summary:
      "Voluptatum delectus ab perferendis ut odio minima sunt.\nQuasi culpa dolorem.\nIllum et officiis illo deserunt officiis optio nesciunt aut.\nPariatur omnis explicabo quaerat ea repellat cupiditate nam.\nIncidunt blanditiis labore totam earum magnam voluptate.",
    glimpse:
      "https://cloudflare-ipfs.com/ipfs/Qmd3W5DuhgHirLHGVixi6V76LhCkZUz6pnFt5AJBiyvHye/avatar/167.jpg",
    director: "Bernadette Schneider Jr.",
    year: 59643,
    cast: [],
    genre: "Funk",
    id: "28",
  },
  {
    name: "Kuhn, Gibson and Gibson",
    poster: "https://loremflickr.com/640/480/cats",
    rating: 53955,
    summary:
      "Molestias nisi quaerat officiis cumque ipsam ipsum.\nAliquam aperiam aperiam facere nostrum blanditiis eligendi non similique.\nExplicabo iste assumenda dolorum repellendus voluptas.\nVoluptates aliquid cupiditate minima veritatis consectetur inventore dolorum.\nExpedita voluptatibus quam suscipit accusantium possimus reiciendis eligendi accusantium.",
    glimpse:
      "https://cloudflare-ipfs.com/ipfs/Qmd3W5DuhgHirLHGVixi6V76LhCkZUz6pnFt5AJBiyvHye/avatar/1088.jpg",
    director: "Raul Ritchie II",
    year: 90445,
    cast: [],
    genre: "Non Music",
    id: "29",
  },
  {
    name: "Dach and Sons",
    poster: "https://loremflickr.com/640/480/cats",
    rating: 476,
    summary:
      "Dolorum aliquid nostrum delectus exercitationem sed reprehenderit officia.\nRecusandae pariatur perspiciatis itaque eius tempora facere libero.\nSoluta ullam ab nulla ipsa adipisci ipsa.\nBlanditiis aspernatur impedit sunt velit.\nCulpa error aspernatur ad soluta quaerat nemo.",
    glimpse:
      "https://cloudflare-ipfs.com/ipfs/Qmd3W5DuhgHirLHGVixi6V76LhCkZUz6pnFt5AJBiyvHye/avatar/37.jpg",
    director: "Dr. Louis Leuschke",
    year: 85702,
    cast: [],
    genre: "Blues",
    id: "30",
  },
  {
    name: "Parker - Johnston",
    poster: "https://loremflickr.com/640/480/cats",
    rating: 48940,
    summary:
      "Consectetur nam expedita incidunt.\nTotam eaque ad hic pariatur deleniti amet amet qui.\nNostrum quisquam blanditiis vel perferendis.",
    glimpse:
      "https://cloudflare-ipfs.com/ipfs/Qmd3W5DuhgHirLHGVixi6V76LhCkZUz6pnFt5AJBiyvHye/avatar/1062.jpg",
    director: "Misty Kutch",
    year: 22194,
    cast: [],
    genre: "Hip Hop",
    id: "31",
    movieName: "pathan",
    movieRating: "7",
    movieYear: "2024",
    movieGenre: "Thriller",
    movieSummary: "abc",
    movieDirector: "abc",
    moviePoster:
      "https://camo.githubusercontent.com/e56453737f3695a5d21d1393764ac1bc89032f5f4d2fc9fa486c980859347275/68747470733a2f2f6178696f732d687474702e636f6d2f6173736574732f6c6f676f2e737667",
  },
  {
    name: "Ferry, Legros and Ledner",
    poster: "https://loremflickr.com/640/480/cats",
    rating: 86389,
    summary:
      "Accusamus cumque dolore incidunt exercitationem deleniti recusandae consectetur earum.\nLaborum voluptatibus numquam tempora.\nIncidunt voluptatum deserunt deleniti corporis illum minus id.\nOptio reprehenderit tenetur occaecati cupiditate asperiores perspiciatis incidunt.",
    glimpse:
      "https://cloudflare-ipfs.com/ipfs/Qmd3W5DuhgHirLHGVixi6V76LhCkZUz6pnFt5AJBiyvHye/avatar/700.jpg",
    director: "Kelli Blick",
    year: 34154,
    cast: [],
    genre: "Blues",
    id: "32",
    movieName: "pathan",
    movieRating: "7",
    movieYear: "2024",
    movieGenre: "Thriller",
    movieSummary: "abc",
    movieDirector: "abc",
    moviePoster:
      "https://camo.githubusercontent.com/e56453737f3695a5d21d1393764ac1bc89032f5f4d2fc9fa486c980859347275/68747470733a2f2f6178696f732d687474702e636f6d2f6173736574732f6c6f676f2e737667",
  },
  {
    name: "abc",
    poster: "abc",
    rating: "abc",
    summary: "abc",
    glimpse:
      "https://cloudflare-ipfs.com/ipfs/Qmd3W5DuhgHirLHGVixi6V76LhCkZUz6pnFt5AJBiyvHye/avatar/436.jpg",
    director: "abc",
    year: "abc",
    cast: [],
    genre: "abc",
    id: "34",
  },
  {
    name: "xyz",
    poster: "xyz",
    rating: "xyz",
    summary: "xyz",
    glimpse:
      "https://cloudflare-ipfs.com/ipfs/Qmd3W5DuhgHirLHGVixi6V76LhCkZUz6pnFt5AJBiyvHye/avatar/445.jpg",
    director: "xyz",
    year: "xyz",
    cast: [],
    genre: "xyz",
    id: "35",
  },
  {
    name: "Her",
    poster:
      "https://m.media-amazon.com/images/M/MV5BMjA1Nzk0OTM2OF5BMl5BanBnXkFtZTgwNjU2NjEwMDE@._V1_FMjpg_UX1000_.jpg",
    rating: "9.5",
    summary:
      "Theodore Twombly, an introverted writer, buys an Artificial Intelligence system to help him write and falls in love with it.",
    glimpse:
      "https://cloudflare-ipfs.com/ipfs/Qmd3W5DuhgHirLHGVixi6V76LhCkZUz6pnFt5AJBiyvHye/avatar/551.jpg",
    director: "Spike Jonze",
    year: "2014",
    cast: [],
    genre: "Romance ",
    id: "36",
  },
  {
    name: "Her",
    poster:
      "https://m.media-amazon.com/images/M/MV5BMjA1Nzk0OTM2OF5BMl5BanBnXkFtZTgwNjU2NjEwMDE@._V1_FMjpg_UX1000_.jpg",
    rating: "9.5",
    summary:
      "Theodore Twombly, an introverted writer, buys an Artificial Intelligence system to help him write. However, when he finds out about the AI's ability to learn and adapt, he falls in love with it.",
    glimpse:
      "https://cloudflare-ipfs.com/ipfs/Qmd3W5DuhgHirLHGVixi6V76LhCkZUz6pnFt5AJBiyvHye/avatar/924.jpg",
    director: "Spike Jonze",
    year: "2014",
    cast: [],
    genre: "Romance",
    id: "37",
  },
  {
    name: "Guide",
    poster:
      "https://assets-in.bmscdn.com/iedb/movies/images/mobile/thumbnail/xlarge/guide-et00016335-1695019535.jpg",
    rating: "9",
    summary:
      "A tourist guide meets an unhappy married woman who wants to take up dancing. With his motivation, she becomes a successful dancer but success corrupts the man's mind.",
    glimpse:
      "https://cloudflare-ipfs.com/ipfs/Qmd3W5DuhgHirLHGVixi6V76LhCkZUz6pnFt5AJBiyvHye/avatar/141.jpg",
    director: "Vijay Anand",
    year: "1965",
    cast: [],
    genre: "Classic",
    id: "38",
  },
];

app.get("/movies", (req, res) => {
  res.send(movies);
});

app.get("/movies/:id", (req, res) => {
  res.send(movies.filter((movie) => movie.id === req.params.id));
});

const movie = [
  {
    name: "Vikram",
    poster:
      "https://m.media-amazon.com/images/M/MV5BMmJhYTYxMGEtNjQ5NS00MWZiLWEwN2ItYjJmMWE2YTU1YWYxXkEyXkFqcGdeQXVyMTEzNzg0Mjkx._V1_.jpg",
    rating: 8.4,
    summary:
      "An action-packed Tamil film follows a fearless and determined police officer as he combats corruption and challenges societal norms to uphold justice.",
  },
  {
    name: "RRR",
    poster:
      "https://englishtribuneimages.blob.core.windows.net/gallary-content/2021/6/Desk/2021_6$largeimg_977224513.JPG",
    rating: 8.8,
    summary:
      "Telgu period action directed by S. S. Rajamouli, featuring the epic tale of two revolutionaries during India's pre-independence era.",
  },
  {
    name: "Iron man 2",
    poster:
      "https://m.media-amazon.com/images/M/MV5BMTM0MDgwNjMyMl5BMl5BanBnXkFtZTcwNTg3NzAzMw@@._V1_FMjpg_UX1000_.jpg",
    rating: 7,
    summary:
      "Tony Stark, pressured to share his Iron Man technology, faces a new enemy while navigating personal challenges with Pepper Potts and James Rhodes by his side.",
  },
  {
    name: "No Country for Old Men",
    poster:
      "https://upload.wikimedia.org/wikipedia/en/8/8b/No_Country_for_Old_Men_poster.jpg",
    rating: 8.1,
    summary:
      "A hunter's discovery of drug money triggers a deadly pursuit by a relentless killer in this gripping tale of chance, fate, and moral ambiguity.",
  },
  {
    name: "Jai Bhim",
    poster:
      "https://m.media-amazon.com/images/M/MV5BY2Y5ZWMwZDgtZDQxYy00Mjk0LThhY2YtMmU1MTRmMjVhMjRiXkEyXkFqcGdeQXVyMTI1NDEyNTM5._V1_FMjpg_UX1000_.jpg",
    summary:
      "A Tamil drama portrays the struggles of a Dalit lawyer fighting against caste discrimination in the Indian legal system, highlighting themes of social justice.",
    rating: 8.8,
  },
  {
    name: "The Avengers",
    rating: 8,
    summary:
      " Marvel's superhero team battles cosmic threats, uniting iconic characters in a thrilling narrative of heroism, teamwork, and sacrifice to protect Earth.",
    poster:
      "https://terrigen-cdn-dev.marvel.com/content/prod/1x/avengersendgame_lob_crd_05.jpg",
  },
  {
    name: "Interstellar",
    poster: "https://m.media-amazon.com/images/I/A1JVqNMI7UL._SL1500_.jpg",
    rating: 8.6,
    summary:
      "Ex-NASA pilot Joseph Cooper leads a perilous mission to find a new planet for humanity's survival, exploring cosmic mysteries and the bonds of love.",
  },
  {
    name: "Baahubali",
    poster: "https://flxt.tmsimg.com/assets/p11546593_p_v10_af.jpg",
    rating: 8,
    summary:
      "Set in Mahishmati, this Telugu epic follows Shivudu's quest for love and identity amidst familial conflicts, political intrigue, and grand battles.",
  },
  {
    name: "Ratatouille",
    poster:
      "https://resizing.flixster.com/gL_JpWcD7sNHNYSwI1ff069Yyug=/ems.ZW1zLXByZC1hc3NldHMvbW92aWVzLzc4ZmJhZjZiLTEzNWMtNDIwOC1hYzU1LTgwZjE3ZjQzNTdiNy5qcGc=",
    rating: 8,
    summary:
      "An animated tale follows Remy, a rat with culinary dreams, as he defies stereotypes to pursue his passion for cooking, serving up a heartwarming story of determination.",
  },
];

app.get("/movie", (req, res) => {
  res.send(movie);
});
const geocode = require("./geocode");
/*
geocode("New York", (error, res) => {
  console.log("this is res", res);
});
*/
app.get("/geolocation", (req, res) => {
  geocode(req.query.location, (error, data) => {
    console.log("geolocation", data);
    if (data) {
      res.send({
        weather_descriptions: data.weather_descriptions[0],
        pressure: data.pressure,
        image_url: data.weather_icons[0],
        observation_time: data.observation_time,
      });
    } else {
      console.log("error is", error);
      res.send({ message: "An error occured, location not found." });
    }
  });
  //server responses in req and res only
});

const { forecast, cbk } = require("./forecast");
//const req = require("express/lib/request");

app.get("/forecast", (req, res) => {
  console.log("this is location", req.query.location);
  geocode(req.query.location, (error, data) => {
    if (data && req.query.location != undefined && req.query.location != "") {
      console.log("data from location", data);
      forecast(data.location.lat, data.location.lon, (error, forecast_data) => {
        if (forecast_data) {
          const { temperature, pressure, humidity, wind_speed } = forecast_data;
          res.send({
            weather_details: {
              temperature,
              pressure,
              humidity,
              wind_speed,
            },
          });
        } else {
          res.send({ message: "Error in fetching weather data via lat lon." });
        }
      });
    } else {
      res.send({ message: "Error in fetching location" });
    }
  });
});
